$(document).ready(function(){
    $('.datepicker').datepicker({
      dateFormat: 'yy-mm-dd',
      changeMonth: true,
      changeYear: true,
      showButtonPanel: true,
      onSelect: function(dateText, inst) {
      }
    });

  $('.btn-primary').on('click', function(e) {
    e.preventDefault(); // Prevent the form from submitting (for demonstration purposes)

    // Show a prompt
    window.alert('Thank you! Your appointment request has been submitted. You will receive a confirmation number within a day.');

    // Simulate sending an email
    const confirmationNumber = generateConfirmationNumber();
    sendEmail('jonnienavada@gmail.com', confirmationNumber);
  });

  // Function to generate a random confirmation number
  function generateConfirmationNumber() {
    return Math.floor(Math.random() * 1000000);
  }

  // Function to simulate sending an email
  function sendEmail(email, confirmationNumber) {
    console.log(`Email sent to ${email} with confirmation number: ${confirmationNumber}`);
    // In a real scenario, you would use AJAX to send an email on the server side.
  }
});