"use strict";
/*    JavaScript 7th Edition
      Chapter 9
      Project 09-01

      Project to read field values from a query string
      Author: 
      Date:   

      Filename: project09-01b.js
*/

